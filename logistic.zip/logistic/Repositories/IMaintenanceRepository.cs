﻿using Logistics.Models;

namespace Logistics.Repositories
{
    public interface IMaintenanceRepository
    {
        List<Maintenance> ViewAll();
        Maintenance ViewSchedule(int id);
        bool ScheduleMaintenance(Maintenance maintenance);
        bool UpdateSchedule(Maintenance maintenance);
        bool RemoveMaintenance(Maintenance maintenance);
    }
}
