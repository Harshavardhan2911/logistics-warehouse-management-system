﻿using Logistics.Models;

namespace Logistics.Repositories
{
    public class InventoryRepository
    {
        LogisticDb con = null;
        public InventoryRepository(LogisticDb con)
        {
            this.con = con;
        }
        public bool AddInventory(Inventory a)
        {
            try
            {
                con.Inventories.Add(a);
                int r = con.SaveChanges();
                if (r > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Details not added sucessfully"+ex.Message);
                return false;
            }
        }
        public bool RemoveInventory(Inventory a)
        {
            try
            {
                con.Inventories.Remove(a);
                int r = con.SaveChanges();
                if (r > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("INventory is not removed" + ex.Message);
                return false;
            }
        }
        public bool UpdateInventory(Inventory a)
        {
            try
            {
                Inventory b = con.Inventories.Find(a.ItemId);
                b.ItemName = a.ItemName;
                b.Category = a.Category;
                b.Quantity = a.Quantity;
                b.Location = a.Location;
                b.LastUpdated = a.LastUpdated;
                int r = con.SaveChanges();
                if (r > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Details not updated" + ex.Message);
                return false;
            }
        }
        public Inventory SearchInventory(int id)
        {
            try
            {
                return con.Inventories.Find(id);
            }
            catch(Exception ex)
            {
                Console.WriteLine("Inventory not found" + ex.Message);
                return null;
            }
        }

        public List<Inventory> ViewInventory()
        {
            try
            {
                return con.Inventories.ToList();
            }
            catch(Exception ex)
            {
                Console.WriteLine("Canno view Inventories" + ex.Message);
                return null;
            }
                
        }
    }
}
