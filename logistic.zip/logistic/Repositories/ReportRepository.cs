﻿using Logistics.Models;

namespace Logistics.Repositories
{
    public class ReportRepository
    {
        LogisticDb ctx = null;
        public ReportRepository(LogisticDb ctx)
        {
            this.ctx = ctx;
        }

        public bool GenerateReport(Report a)
        {
            try
            {
                ctx.Reports.Add(a);
                int r = ctx.SaveChanges();
                if (r > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception ex)
            {
                return false;
            }
        }
        public Report DownloadReport(int id)
        {
            return ctx.Reports.Find(id);
        }
        public List<Report> ViewReports()
        {
            return ctx.Reports.ToList();
        }
    }
}