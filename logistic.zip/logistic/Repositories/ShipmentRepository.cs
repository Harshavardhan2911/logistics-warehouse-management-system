﻿using Logistics.Models;
using Logistics.Repositories;

namespace Logistics.Repositories
{
    public class ShipmentRepository
    {
        LogisticDb con = null;
        public ShipmentRepository(LogisticDb con)
        {
            this.con = con;
        }
        public bool ReceiveShipment(Shipment shipment)
        {
            try
            {
                con.Shipments.Add(shipment);
                int r = con.SaveChanges();
                if (r > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception ex){
                return false;
            }

        }
        public bool RemoveShipment(Shipment shipment)
        {
            try
            {
                con.Shipments.Remove(shipment);
                int r = con.SaveChanges();
                if (r > 0)
                {
                    return true;
                }
                return false;
            }
            catch(Exception ex)
            {
                return false;
            }
        }
        public bool DispatchShipment(Shipment shipment)
        {
            try
            {
                Shipment s = con.Shipments.Find(shipment.ShipmentId);
                s.ItemId = shipment.ItemId;
                s.Origin = shipment.Origin;
                s.Destination = shipment.Destination;
                s.Status = shipment.Status;
                s.ExpectedDelivery = shipment.ExpectedDelivery;
                int r = con.SaveChanges();
                if (r > 0)
                {
                    return true;
                }
                return false;
            }
            catch(Exception ex)
            {
                return false;
            }
        }
        public Shipment TrackShipment(int id)
        {
            return con.Shipments.Find(id);
        }
        public List<Shipment> ViewShipment()
        {
            return con.Shipments.ToList();
        }
    }
}