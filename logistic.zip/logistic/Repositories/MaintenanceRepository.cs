﻿using Humanizer;
using Logistics.Models;

namespace Logistics.Repositories
{
    public class MaintenanceRepository:IMaintenanceRepository
    {
        LogisticDb ctx = null;
        public MaintenanceRepository(LogisticDb ctx)
        {
            this.ctx=ctx;
        }

        public bool ScheduleMaintenance(Maintenance b)
        {
            try
            {
                ctx.Maintenances.Add(b);
                int r = ctx.SaveChanges();
                if (r > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }catch(Exception ex)
            {
                return false;
            }
        }
        public bool UpdateSchedule(Maintenance b)
        {
            try
            {
                Maintenance c = ctx.Maintenances.Find(b.ScheduleId);
                c.EquipmentId = b.EquipmentId;
                c.Description = b.Description;
                c.ScheduledDate = b.ScheduledDate;
                c.CompletionStatus = b.CompletionStatus;
                int r = ctx.SaveChanges();
                if (r > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception ex)
            {
                return false;
            }

        }
        public bool RemoveMaintenance(Maintenance a)
        {
            try
            {
                ctx.Maintenances.Remove(a);
                int r = ctx.SaveChanges();
                if (r > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception ex){
                return false;
            }
        }
        public Maintenance ViewSchedule(int id)
        {
            return ctx.Maintenances.Find(id);
        }
        public List<Maintenance> ViewAll()
        {
            return ctx.Maintenances.ToList();
        }
    }
}
