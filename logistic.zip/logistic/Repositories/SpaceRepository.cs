﻿using Logistics.Models;

namespace Logistics.Repositories
{
    public class SpaceRepository
    {
        LogisticDb con = null;
        public SpaceRepository(LogisticDb con)
        {
            this.con = con;
        }
        public bool AllocateSpace(Space space)

        {

            con.Spaces.Add(space);

            int r = con.SaveChanges();

            if (r > 0)

            {

                return true;

            }

            else

            {

                return false;

            }

        }
        public bool FreeSpace(Space space)

        {

            con.Spaces.Remove(space);

            int r = con.SaveChanges();

            if (r > 0)

            {

                return true;

            }

            else

            {

                return false;

            }

        }
        public bool UpdateSpace(Space space)
        {
            Space s = con.Spaces.Find(space.SpaceId);
            s.TotalCapacity = space.TotalCapacity;
            s.UsedCapacity = space.UsedCapacity;
           // s.AvailableCapacity = space.AvailableCapacity;
            s.Zone = space.Zone;
            int r = con.SaveChanges();
            if (r > 0)
            {
                return true;
            }
            return false;
        }
        public Space SearchSpace(int id)
        {
            return con.Spaces.Find(id);
        }
        public List<Space> ViewSpaceUsage()
        {
            return con.Spaces.ToList();
        }
    }
}