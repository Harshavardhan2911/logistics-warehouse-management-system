﻿using Logistics.Models;
using System.Text.RegularExpressions;
namespace Logistics.Repositories
{
    public class InformationRepository
    {
        LogisticDb a = null;
        public InformationRepository(LogisticDb b)
        {
            this.a = b;
        }
        public bool AddInformation(Information c)
        {
            bool b = false;
            try {
                string pattern = @"^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$";
                bool isvalid = Regex.IsMatch(c.Password, pattern);
                if (isvalid)
                {
                    a.Informations.Add(c);
                    int r = a.SaveChanges();

                    if (r > 0)
                    {
                        b = true;

                    }
                }
                
            }
            catch(Exception ex)
            {
                Console.WriteLine("Insert operation failed" + ex.Message);
                b = false;
            }
            return b;
        }
        public bool SearchInformation(Information c)
        {
            Information b = a.Informations.Find(c.EmailId);
            if (b != null)
            {
                if (b.Password == c.Password&&b.Role==c.Role)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }


        }

        public Information GetInformationByEmail(string Email)
        {
            return a.Informations.Find(Email);
        }

    }
}
