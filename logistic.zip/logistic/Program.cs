using Logistics.Models;
using Logistics.Repositories;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using Logistics.Filters;
using Microsoft.AspNetCore.Mvc;

var builder = WebApplication.CreateBuilder(args);
var conString = builder.Configuration.GetConnectionString("EventConnection");
builder.Services.AddDbContextPool<LogisticDb>(options => options.UseSqlServer(conString));
builder.Services.AddScoped<IMaintenanceRepository, MaintenanceRepository>();

builder.Services.AddScoped<InformationRepository>();
builder.Services.AddScoped<SessionCheckFilter>();
builder.Services.AddHttpContextAccessor();

builder.Services.AddControllersWithViews(options =>
{
    options.Filters.Add(new ResponseCacheAttribute
    {
        NoStore = true,
        Location = ResponseCacheLocation.None,
        Duration = 0
    });
});
builder.Services.AddHttpClient();
builder.Services.AddCors();

builder.Services.AddSession();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Home/Index";
        options.AccessDeniedPath = "/Home/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromMinutes(30);
        options.SlidingExpiration = true;
        options.Cookie.HttpOnly = true;
        options.Cookie.IsEssential = true;
    });


var app = builder.Build();


if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseSession();
app.UseAntiforgery();
app.Use(async (context, next) =>
{
    context.Response.Headers.Add("Cache-Control", "no-store, must-revalidate");
    context.Response.Headers.Add("Pragma", "no-cache");
    await next();
});

app.UseAuthentication();
app.UseAuthorization();

app.UseStatusCodePagesWithReExecute("/Error/{0}");

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.UseCors(options => options.WithOrigins("http://localhost:7285")
                              .AllowAnyMethod()
                              .AllowAnyHeader()
                              .AllowCredentials());

app.Run();