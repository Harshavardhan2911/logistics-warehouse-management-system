﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Logistics.Migrations
{
    /// <inheritdoc />
    public partial class file7 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Informations",
                columns: new[] { "EmailId", "Password" },
                values: new object[,]
                {
                    { "admin1@gmail.com", "Admin1234!@#$" },
                    { "admin2@gmail.com", "Admin1234!@#" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Informations",
                keyColumn: "EmailId",
                keyValue: "admin1@gmail.com");

            migrationBuilder.DeleteData(
                table: "Informations",
                keyColumn: "EmailId",
                keyValue: "admin2@gmail.com");
        }
    }
}
