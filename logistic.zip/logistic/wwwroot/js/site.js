﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
    const INACTIVITY_TIMEOUT = 30 * 60 * 1000;

    let inactivityTimer;

    // Function to reset the inactivity timer
    function resetInactivityTimer() {
        clearTimeout(inactivityTimer);
    inactivityTimer = setTimeout(logoutUser, INACTIVITY_TIMEOUT);
    }

    // Function to log out the user and redirect to the home page
    function logoutUser() {
        alert("You have been logged out due to inactivity.");
    window.location.href = 'https://localhost:7117/Home/SignOut';// Change '/home' to your actual home page URL
    }

    // Event listeners to detect user activity
    window.onload = resetInactivityTimer;
    window.onmousemove = resetInactivityTimer;
    window.onkeypress = resetInactivityTimer;
    window.ontouchstart = resetInactivityTimer;
    window.onclick = resetInactivityTimer;

    // Initialize the inactivity timer when the page loads
    resetInactivityTimer();

