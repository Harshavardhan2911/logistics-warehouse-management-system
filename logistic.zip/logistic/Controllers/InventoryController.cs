﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Logistics.Models;
using Logistics.Repositories;
using System.Collections.Generic;
using Logistics.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages.Manage;
namespace Logistics.Controllers
{
    

    public class InventoryController : Controller
    {
        private readonly InventoryRepository invRep;
     

        public InventoryController(LogisticDb context)
        {
            invRep = new InventoryRepository(context);
           
        }

       
        [ServiceFilter(typeof(SessionCheckFilter))]
        public ActionResult Welcome()
        {
         
            string email = HttpContext.Session.GetString("EmailId");


            if (string.IsNullOrEmpty(email))
            {
                return RedirectToAction("Index", "Home");
            }

            ViewBag.User = email;
            return View();
        }
        [ServiceFilter(typeof(SessionCheckFilter))]


        
        public ActionResult Index()
        {
            
            List<Inventory> inventoryList = invRep.ViewInventory();
            string email = HttpContext.Session.GetString("EmailId");


            if (string.IsNullOrEmpty(email))
            {
                return RedirectToAction("Index", "Home");
            }

            string role = HttpContext.Session.GetString("Role");
            ViewBag.User = email;
            ViewBag.Role = role;
            return View(inventoryList);
        }

        public ActionResult Search(int id)
        {
            Inventory inventory = invRep.SearchInventory(id);  
            string role = HttpContext.Session.GetString("Role");
            ViewBag.Role = role;

            if (inventory == null)
            {
                ViewBag.ErrorMessage = "Inventory item not found.";
                return View(new Inventory());
            }
            if (string.IsNullOrEmpty(role))
            {
                return RedirectToAction("Index", "Home");
            }
            return View(inventory);
        }

        public ActionResult Details(int id)
        {
           
            Inventory inventory = invRep.SearchInventory(id);
            return View(inventory);
        }

        public ActionResult Create()
        {
            
            Inventory inventory = new Inventory();
            return View(inventory);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValueErrorFilter]
        public ActionResult Create(Inventory inventory)
        {
            

         
            
                bool isAdded = invRep.AddInventory(inventory);
                if (isAdded)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    return View(inventory); 
               
                 }
           
        }
        public ActionResult Edit(int id)
        {
           
            Inventory inventory = invRep.SearchInventory(id);
            string role = HttpContext.Session.GetString("Role");
            ViewBag.Role = role;
            return View(inventory);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Inventory inventory)
        {
        
            try
            {
                invRep.UpdateInventory(inventory);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Delete(int id)
        {
           
            Inventory inventory = invRep.SearchInventory(id);
            invRep.RemoveInventory(inventory);
            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
          
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
