﻿using Logistics.Repositories;
using Logistics.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Logistics.Filters;

namespace Logistics.Controllers
{
    
    public class ShipmentController : Controller
    {
        // GET: ShipmentController
        ShipmentRepository shipRep = null;
        public ShipmentController(LogisticDb ctx)
        {
            shipRep = new ShipmentRepository(ctx);
        }
        [ServiceFilter(typeof(SessionCheckFilter))]
        public ActionResult Index()
        {
            List<Shipment> s = shipRep.ViewShipment();
            string email = HttpContext.Session.GetString("EmailId");


            if (string.IsNullOrEmpty(email))
            {
                return RedirectToAction("Index", "Home");
            }

            string role = HttpContext.Session.GetString("Role");
            ViewBag.User = email;
            ViewBag.Role = role;
            return View(s);
        }
        public ActionResult Search(int id)
        {
            Shipment b = shipRep.TrackShipment(id);
            if (b == null)
            {
                ViewBag.ErrorMessage = "Inventory item not found.";
                return View(new Shipment()); 
            }
            string role = HttpContext.Session.GetString("Role");
            ViewBag.Role = role;
            return View(b);
        }

        // GET: ShipmentController/Details/5
        public ActionResult Details(int id)
        {
            Shipment ship = shipRep.TrackShipment(id);
            return View(ship);
        }

        // GET: ShipmentController/Create
        public ActionResult Create()
        {
            Shipment s = new Shipment();
            return View(s);
        }

        // POST: ShipmentController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Shipment s)
        {
            try
            {
                bool b = shipRep.ReceiveShipment(s);
                if (b)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    return View();
                }
            }
            catch
            {
                return View();
            }
        }

        // GET: ShipmentController/Edit/5
        public ActionResult Edit(int id)
        {
            Shipment s = shipRep.TrackShipment(id);
            string role = HttpContext.Session.GetString("Role");
            ViewBag.Role = role;
            return View(s);
        }

        // POST: ShipmentController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Shipment s)
        {
            try
            {
                shipRep.DispatchShipment(s);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: ShipmentController/Delete/5
        public ActionResult Delete(int id)
        {
            Shipment s = shipRep.TrackShipment(id);
            shipRep.RemoveShipment(s);
            return RedirectToAction("Index");
        }

        // POST: ShipmentController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}