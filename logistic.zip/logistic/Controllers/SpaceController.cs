﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using WebApi.Models;
using System.Collections.Generic;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Text;
using Logistics.Filters;
namespace Logistics.Controllers
{

    public class SpaceController : Controller
    {
        // GET: SpaceController
        private readonly HttpClient _client;

        public SpaceController(HttpClient client)
        {
            _client = client;
            _client.BaseAddress = new Uri("https://localhost:7285/api/Space/");
        }

        // GET: SpaceController
        [ServiceFilter(typeof(SessionCheckFilter))]
        public async Task<IActionResult> Index()

        {
            
            string email = HttpContext.Session.GetString("EmailId");


            if (string.IsNullOrEmpty(email))
            {
                return RedirectToAction("Index", "Home");
            }

            string role = HttpContext.Session.GetString("Role");
            ViewBag.User = email;
            ViewBag.Role = role;
            List<Space> details = null;
            try
            {
                details = await _client.GetFromJsonAsync<List<Space>>("Get");
            }
            catch (HttpRequestException ex)
            {
                ViewBag.Error = "Error fetching data from the API: " + ex.Message;
            }
            return View(details);
        }

        // GET: SpaceController/Details/5
        public async Task<IActionResult> Details(int id)
        {
            Space space = null;
            try
            {
                space = await _client.GetFromJsonAsync<Space>($"Get/{id}");
            }
            catch (HttpRequestException ex)
            {
                ViewBag.Error = "Error fetching data from the API: " + ex.Message;
            }
            return View(space);
        }

        // GET: SpaceController/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: SpaceController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Space space)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var response = await _client.PostAsJsonAsync("Insert", space);
                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction(nameof(Index));
                    }
                    ViewBag.Error = "Error creating space: " + response.ReasonPhrase;
                }
                catch (HttpRequestException ex)
                {
                    ViewBag.Error = "Error creating space: " + ex.Message;
                }
            }
            return View(space);
        }

        // GET: SpaceController/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            Space space = null;
            try
            {
                space = await _client.GetFromJsonAsync<Space>($"Get/{id}");
            }
            catch (HttpRequestException ex)
            {
                ViewBag.Error = "Error fetching data from the API: " + ex.Message;
            }
            return View(space);
        }

        // POST: SpaceController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Space space)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    string role = HttpContext.Session.GetString("Role");
                    ViewBag.Role = role;
                    var response = await _client.PutAsJsonAsync($"Put/{id}", space);
                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction(nameof(Index));
                    }
                    ViewBag.Error = "Error updating space: " + response.ReasonPhrase;
                }
                catch (HttpRequestException ex)
                {
                    ViewBag.Error = "Error updating space: " + ex.Message;
                }
            }
            return View(space);
        }

        // GET: SpaceController/Delete/5
        public async Task<ActionResult> DeleteSpace(int id)
        {
            
            var response = await _client.DeleteAsync($"Delete/{id}");
           
            if (response.IsSuccessStatusCode)
            {
                
                return RedirectToAction("Index");
            }
            

            return View();

           
        }


    }
}
