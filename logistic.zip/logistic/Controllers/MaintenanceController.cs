﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Logistics.Models;
using Logistics.Repositories;
using Microsoft.AspNetCore.Authorization;
using Logistics.Controllers;
using Logistics.Filters;

namespace Logistics.Controllers
{
  
    public class MaintenanceController : Controller 
    {
        // GET: MaintenanceController
        IMaintenanceRepository mainRep = null;
        public MaintenanceController(IMaintenanceRepository _mainRep)
        {
            mainRep = _mainRep;
        }
        [ServiceFilter(typeof(SessionCheckFilter))]
        public ActionResult Index()
        {
            
            List<Maintenance> a = mainRep.ViewAll();
            string email = HttpContext.Session.GetString("EmailId");


            if (string.IsNullOrEmpty(email))
            {
                return RedirectToAction("Index", "Home");
            }

            string role = HttpContext.Session.GetString("Role");
            ViewBag.User = email;
            ViewBag.Role = role;
            Console.WriteLine("hello"+mainRep.GetHashCode());
            return View(a);
        }
        public ActionResult Search(int id)
        {
            Maintenance b = mainRep.ViewSchedule(id);
            if (b== null)
            {
                ViewBag.ErrorMessage = "Inventory item not found.";
                return View(new Maintenance()); 
            }
            string role = HttpContext.Session.GetString("Role");
            ViewBag.Role = role;
            return View(b);
        }
        // GET: MaintenanceController/Details/5
        public ActionResult Details(int id)
        {
            Maintenance a=mainRep.ViewSchedule(id);
            Console.WriteLine("hi"+mainRep.GetHashCode());
            return View(a);
        }

        // GET: MaintenanceController/Create
        public ActionResult Create()
        {
            Maintenance a = new Maintenance();
            return View(a);
        }

        // POST: MaintenanceController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Maintenance a)
        {
            if (ModelState.IsValid)
            {
                try
                {

                    bool b = mainRep.ScheduleMaintenance(a);
                    if (b)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        return View();
                    }
                }
                catch
                {
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

        // GET: MaintenanceController/Edit/5
        public ActionResult Edit(int id)
        {
            Maintenance a = mainRep.ViewSchedule(id);
            string role = HttpContext.Session.GetString("Role");
            ViewBag.Role = role;

            return View(a);
        }

        // POST: MaintenanceController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Maintenance a)
        {
            try
            {
                mainRep.UpdateSchedule(a);


                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: MaintenanceController/Delete/5
        public ActionResult Delete(int id)
        {
            Maintenance a = mainRep.ViewSchedule(id);
            mainRep.RemoveMaintenance(a);
            return RedirectToAction("Index");
        }

        // POST: MaintenanceController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
