using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http; 
using Logistics.Models;
using Logistics.Repositories;
using Microsoft.AspNetCore.Authentication;
using NuGet.Protocol;
using System.Diagnostics;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace logistic.Controllers
{
    public class HomeController : Controller
    {
        private readonly InformationRepository _ctx;

        public HomeController(LogisticDb a)
        {
            _ctx = new InformationRepository(a);
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(Information a)
        {
            bool b = _ctx.SearchInformation(a);
            if (b)
            {
                string email = a.EmailId;
                HttpContext.Session.SetString("EmailId", email);
                string role = a.Role;
                HttpContext.Session.SetString("Role", role);

               
                return RedirectToAction("Welcome", "Inventory");
            }
            else
            {
                TempData["ErrorMessage"] = "Invalid login credentials.";
                return View(a);
            }
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Information a)
        {
            bool b = _ctx.AddInformation(a);
            if (b)
            {
                TempData["SuccessMessage"] = "Details have been added successfully.";
                return RedirectToAction("Create");
            }
            else
            {
                TempData["ErrorMessage"] = "Details not Added Successfully.";
                return View("Create");
            }
        }

        public IActionResult SignOut()
        {
            HttpContext.Session.Clear();
            HttpContext.Response.Cookies.Delete(CookieAuthenticationDefaults.CookiePrefix + CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Home");
        }

        public IActionResult Privacy()
        {
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
          
            return View("Error");
        }
      
           
    }
}
