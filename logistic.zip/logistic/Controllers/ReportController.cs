﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Logistics.Models;
using Logistics.Repositories;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages.Manage;
using Microsoft.AspNetCore.Authorization;
using Logistics.Filters;
namespace Logistics.Controllers
{
   
    public class ReportController : Controller
    {
        // GET: ReportController
        ReportRepository repRep = null;
        public ReportController(LogisticDb a)
        {
            repRep = new ReportRepository(a);
        }
        [ServiceFilter(typeof(SessionCheckFilter))]
        public ActionResult Index()
        {
            List<Report> a = repRep.ViewReports();
            string email = HttpContext.Session.GetString("EmailId");


            if (string.IsNullOrEmpty(email))
            {
                return RedirectToAction("Index", "Home");
            }

            string role = HttpContext.Session.GetString("Role");
            ViewBag.User = email;
            ViewBag.Role = role;
            return View(a);
        }
        public ActionResult Search(int id)
        {
            Report b = repRep.DownloadReport(id);
            if (b == null)
            {
                ViewBag.ErrorMessage = "Inventory item not found.";
                return View(new Report()); 
            }
            return View(b);
        }
        // GET: ReportController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ReportController/Create
        public ActionResult Create()
        {
            Report a = new Report();
            return View(a);
        }

        // POST: ReportController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Report a)
        {
            try
            {
                bool b = repRep.GenerateReport(a);
                if (b)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    return View();
                }
            }
            catch
            {
                return View();
            }
        }

        // GET: ReportController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ReportController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ReportController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ReportController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
