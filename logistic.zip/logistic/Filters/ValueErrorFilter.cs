﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Logistics.Models; // Add this using statement.

namespace Logistics.Filters
{
    public class ValueErrorFilter : ActionFilterAttribute
    {
     

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (context.ActionArguments.ContainsKey("inventory") && context.ActionArguments["inventory"] is Inventory inventory)
            {
                if (inventory.Quantity < 0)
                {
                    context.Result = new BadRequestObjectResult("Quantity should not be less than zero.");
                    return; 
                }
            }
            base.OnActionExecuting(context);
        }
    }
}