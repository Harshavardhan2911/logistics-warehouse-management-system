﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Http;
using Logistics.Repositories;
using Logistics.Models;

namespace Logistics.Filters
{
    public class SessionCheckFilter : IActionFilter
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly InformationRepository _infoRep;

        public SessionCheckFilter(IHttpContextAccessor httpContextAccessor, InformationRepository infoRep)
        {
            _httpContextAccessor = httpContextAccessor;
            _infoRep = infoRep;
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            var session = _httpContextAccessor.HttpContext.Session;
            string email = session.GetString("EmailId");
            if (!string.IsNullOrEmpty(email))
            {
                Information userInfo = _infoRep.GetInformationByEmail(email);
                if (userInfo != null)
                {
                    session.SetString("Role", userInfo.Role);
                }
            }
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            
        }
    }
}
