﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Logistics.Models
{
    public class Space
    {
        [Key]

        public int SpaceId { get; set; }
        [Required(ErrorMessage ="Total Capacity is Required"),Range(1,10000)]
        public int TotalCapacity { get; set; }
        [Required(ErrorMessage ="Used Capacity is required"),Range(0,10000)]
        public int UsedCapacity { get; set; }
        [Required,Range(0,10000)]
        public int AvailableCapacity
        {
            get
            {
                return TotalCapacity - UsedCapacity;
            }
        }

        public string Zone { get; set; }
    }
}
