﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Logistics.Models
{
    public class Shipment
    {
        [Key]
        public int ShipmentId { get; set; }
        [Required(ErrorMessage = "Item Id is required")]
        [ForeignKey("Inventory")]
        public int? ItemId { get; set; } = null;
        
        public virtual Inventory Inventory { get; set; }
        [Required(ErrorMessage ="Origin is required")]
        public string Origin { get; set; }
        [Required(ErrorMessage ="Destination is required")]
        public string Destination { get; set; }
        [Required(ErrorMessage ="Status is required")]
        public string Status { get; set; }
        [Required(ErrorMessage ="Expected Delivery is required")]

        public DateTime ExpectedDelivery { get; set; }
       
    }
}