﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Logistics.Models
{
    public class Maintenance
    {
        [Key]
        public int ScheduleId { get; set; }
        [Required(ErrorMessage = "EquipmentId is required")]
        public int? EquipmentId { set; get; } = null;
        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; } = string.Empty;
        [Required(ErrorMessage ="Scheduledate is Required")]
        public DateTime ScheduledDate { get; set; }
        [Required(ErrorMessage ="Completion Status is Required")]
        public string CompletionStatus { get; set; }
        
    }
    
}
