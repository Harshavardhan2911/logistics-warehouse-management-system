﻿using Microsoft.EntityFrameworkCore;
using WebApi.Models;

namespace Logistics.Models
{
    public class LogisticDb : DbContext
    {
        public LogisticDb(DbContextOptions<LogisticDb> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Information>().HasData(
                new Information { EmailId = "admin1@gmail.com", Password = "Admin1234!@#$" ,Role="SuperAdmin"},
                new Information { EmailId = "admin2@gmail.com", Password = "Admin1234!@#",Role="Admin" }
            );
        }

        public virtual DbSet<Inventory> Inventories { get; set; }
        public virtual DbSet<Maintenance> Maintenances { get; set; }
        public virtual DbSet<Shipment> Shipments { get; set; }
        public virtual DbSet<Space> Spaces { get; set; }
        public virtual DbSet<Report> Reports { get; set; }
        public virtual DbSet<Information> Informations { get; set; }
        public DbSet<WebApi.Models.Space> Space { get; set; } = default!;
    }
}