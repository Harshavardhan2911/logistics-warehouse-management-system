﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Logistics.Models
{
    public class Report
    {
        [Key]
        public int ReportId { get; set; }
        [Required(ErrorMessage ="Report Type is required")]
        public string ReportType { get; set; }
        [Required(ErrorMessage ="Generated On is required")]
        public DateTime GeneratedOn { get; set; }
        [Required(ErrorMessage ="Details is required")]
        public string Details { get; set; }
       
    }
}
