﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Logistics.Models
{
    public class Inventory
    {
        [Key]

        public int ItemId { get; set; }
        [Required(ErrorMessage = "ItemName is required"), MaxLength(20)]
        public string ItemName { get; set; } = string.Empty;
        [Required(ErrorMessage = "Category is required"), MaxLength(40)]
        public string Category { get; set; } = string.Empty;
        [Required(ErrorMessage = "Quantity is required")]

        public int? Quantity { get; set; } = null;
        [Required(ErrorMessage = "Location is required")]
        public string Location { get; set; } = string.Empty;
        [Required(ErrorMessage = "LastUpdated is required")]
        public DateTime LastUpdated { get; set; }
       
        public virtual ICollection<Shipment> Shipments { get; set; }
    }
}
